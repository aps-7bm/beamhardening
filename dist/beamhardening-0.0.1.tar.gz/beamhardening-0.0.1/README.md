# beamhardening

This is a package to correct for beam hardening in 
synchrotron WB imaging from bending magenet sources.

Typical usage:
